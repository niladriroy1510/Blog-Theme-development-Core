


<?php

function mytheme_add_custom_meta_boxes() {
    add_meta_box(
        'mytheme_page_options',            // Unique ID
        __( 'Page Options', 'mytheme' ),   // Box title
        'mytheme_display_meta_box',        // Callback function
        'page',                            // Post type
        'normal',                          // Context
        'high'                             // Priority
    );
}
add_action( 'add_meta_boxes', 'mytheme_add_custom_meta_boxes' );

?>


<?php

function mytheme_display_meta_box( $post ) {
    wp_nonce_field( 'mytheme_save_meta_box_data', 'mytheme_meta_box_nonce' );

    echo '<style>
        .mytheme-meta-box label { display: block; font-weight: bold; margin: 10px 0 5px; }
        .mytheme-meta-box input[type="text"], .mytheme-meta-box textarea { width: 100%; max-width: 400px; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        .mytheme-meta-box .checkbox-container { display: flex; align-items: center; }
        .mytheme-meta-box input[type="checkbox"] { margin-right: 10px; }
    </style>';

    echo '<div class="mytheme-meta-box">';

    // Text input
    echo '<label for="mytheme_text">' . __( 'Text Input:', 'mytheme' ) . '</label>';
    echo '<input type="text" id="mytheme_text" name="mytheme_text" value="' . esc_attr( get_post_meta( $post->ID, '_mytheme_text', true ) ) . '" />';

    // Textarea input
    echo '<label for="mytheme_textarea">' . __( 'Textarea:', 'mytheme' ) . '</label>';
    echo '<textarea id="mytheme_textarea" name="mytheme_textarea" rows="4">' . esc_textarea( get_post_meta( $post->ID, '_mytheme_textarea', true ) ) . '</textarea>';

    // Checkbox
    echo '<div class="checkbox-container">';
    echo '<input type="checkbox" id="mytheme_checkbox" name="mytheme_checkbox" ' . checked( get_post_meta( $post->ID, '_mytheme_checkbox', true ), 'on', false ) . ' />';
    echo '<label for="mytheme_checkbox">' . __( 'Enable Feature', 'mytheme' ) . '</label>';
    echo '</div>';

    echo '</div>';
}

?>


<?php

function mytheme_save_meta_box_data( $post_id ) {
    if ( ! isset( $_POST['mytheme_meta_box_nonce'] ) || ! wp_verify_nonce( $_POST['mytheme_meta_box_nonce'], 'mytheme_save_meta_box_data' ) ) {
        return;
    }

    if ( isset( $_POST['mytheme_text'] ) ) {
        update_post_meta( $post_id, '_mytheme_text', sanitize_text_field( $_POST['mytheme_text'] ) );
    }

    if ( isset( $_POST['mytheme_textarea'] ) ) {
        update_post_meta( $post_id, '_mytheme_textarea', sanitize_textarea_field( $_POST['mytheme_textarea'] ) );
    }

    $checkbox_value = isset( $_POST['mytheme_checkbox'] ) ? 'on' : '';
    update_post_meta( $post_id, '_mytheme_checkbox', $checkbox_value );
}
add_action( 'save_post', 'mytheme_save_meta_box_data' );

?>





<?php
$post_id = get_the_ID();
$text_value = get_post_meta( $post_id, '_mytheme_text', true );
$textarea_value = get_post_meta( $post_id, '_mytheme_textarea', true );
$checkbox_value = get_post_meta( $post_id, '_mytheme_checkbox', true );
$color_value = get_post_meta( $post_id, '_mytheme_color', true ); // Retrieve if exists
?>

<div class="custom-page-options" style="color: <?php echo esc_attr( $color_value ); ?>;">
    <?php if ( ! empty( $text_value ) ) : ?>
        <p><?php echo esc_html( $text_value ); ?></p>
    <?php endif; ?>

    <?php if ( ! empty( $textarea_value ) ) : ?>
        <p><?php echo nl2br( esc_html( $textarea_value ) ); ?></p>
    <?php endif; ?>

    <?php if ( 'on' === $checkbox_value ) : ?>
        <p><?php _e( 'Feature is enabled!', 'mytheme' ); ?></p>
    <?php else : ?>
        <p><?php _e( 'Feature is disabled.', 'mytheme' ); ?></p>
    <?php endif; ?>
</div>
