<?php


	function MarcoBlog_customize_register( $wp_customize ) {
		// Add a section for social media links
		$wp_customize->add_section( 'social_links_section', array(
			'title'    => __( 'Social Media Links Header', 'marco' ),
			'priority' => 30,
		) );

		// Add setting for Facebook
		$wp_customize->add_setting( 'facebook_link', array(
			'default'   => 'https://www.facebook.com/web5g',
			'transport' => 'refresh',
			'sanitize_callback' => 'esc_url_raw',
		) );
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'facebook_link_control', array(
			'label'    => __( 'Facebook URL', 'marco' ),
			'section'  => 'social_links_section',
			'settings' => 'facebook_link',
			'type'     => 'url',
		) ) );

		// Add setting for Twitter
		$wp_customize->add_setting( 'twitter_link', array(
			'default'   => 'https://x.com',
			'transport' => 'refresh',
			'sanitize_callback' => 'esc_url_raw',
		) );
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'twitter_link_control', array(
			'label'    => __( 'Twitter URL', 'marco' ),
			'section'  => 'social_links_section',
			'settings' => 'twitter_link',
			'type'     => 'url',
		) ) );

		// Add setting for Instagram
		$wp_customize->add_setting( 'instagram_link', array(
			'default'   => 'https://www.instagram.com',
			'transport' => 'refresh',
			'sanitize_callback' => 'esc_url_raw',
		) );
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'instagram_link_control', array(
			'label'    => __( 'Instagram URL', 'marco' ),
			'section'  => 'social_links_section',
			'settings' => 'instagram_link',
			'type'     => 'url',
		) ) );
		
		
		// Add setting for linkedin
		$wp_customize->add_setting( 'linkedin_link', array(
			'default'   => 'https://bd.linkedin.com',
			'transport' => 'refresh',
			'sanitize_callback' => 'esc_url_raw',
		) );
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'linkedin_link_control', array(
			'label'    => __( 'linkedin URL', 'marco' ),
			'section'  => 'social_links_section',
			'settings' => 'linkedin_link',
			'type'     => 'url',
		) ) );

		// Add more social networks as needed
	}

	add_action( 'customize_register', 'MarcoBlog_customize_register' );
