<?php

/////////////////////////////OutPut///////////////////////////////////////

1. Text Input ///////////////////////////////////////

<?php echo esc_html( get_theme_mod( 'mytheme_text_setting', 'Default Text' ) ); ?>

2. Textarea (type: 'textarea') ///////////////////////////////////////

<?php echo wp_kses_post( get_theme_mod( 'mytheme_textarea_setting', 'Default Textarea Content' ) ); ?>

3. Checkbox (type: 'checkbox') ///////////////////////////////////////

<?php if ( get_theme_mod( 'mytheme_checkbox_setting', false ) ) : ?>
    <p>The checkbox is checked!</p>
<?php else : ?>
    <p>The checkbox is not checked.</p>
<?php endif; ?>

4. Radio Buttons (type: 'radio') ///////////////////////////////////////

<?php
	$radio_value = get_theme_mod( 'mytheme_radio_setting', 'option1' );
	if ( $radio_value == 'option1' ) {
		echo '<p>Option 1 is selected.</p>';
	} elseif ( $radio_value == 'option2' ) {
		echo '<p>Option 2 is selected.</p>';
	} elseif ( $radio_value == 'option3' ) {
		echo '<p>Option 3 is selected.</p>';
	}
?>

5. Select Dropdown (type: 'select') ///////////////////////////////////////

<?php
	$select_value = get_theme_mod( 'mytheme_select_setting', 'option1' );
	echo '<p>Selected value: ' . esc_html( $select_value ) . '</p>';
?>

6. Color Picker (WP_Customize_Color_Control) ///////////////////////////////////////

<?php
	$color_value = get_theme_mod( 'mytheme_color_setting', '#000000' );
	echo '<div style="color:' . esc_attr( $color_value ) . ';">This text is colored.</div>';
?>

7. Image Upload (WP_Customize_Image_Control) ///////////////////////////////////////

<?php
	$image_url = get_theme_mod( 'mytheme_image_setting' );
	if ( $image_url ) {
		echo '<img src="' . esc_url( $image_url ) . '" alt="Custom Image" />';
	}
?>

8. File Upload (WP_Customize_Upload_Control) ///////////////////////////////////////

<?php
	$file_url = get_theme_mod( 'mytheme_file_setting' );
	if ( $file_url ) {
		echo '<a href="' . esc_url( $file_url ) . '">Download File</a>';
	}
?>

9. Range Slider (type: 'range') ///////////////////////////////////////

<?php
	range_value = get_theme_mod( 'mytheme_range_setting', 50 );
	echo '<p>Range Value: ' . esc_html( $range_value ) . '</p>';
?>

10. Date from the Customizer //////////////////////////////////////

<?php
	$date_value = get_theme_mod( 'mytheme_date_setting', date( 'Y-m-d' ) );
	echo '<p>Selected Date: ' . esc_html( date( 'F j, Y', strtotime( $date_value ) ) ) . '</p>';
?>





//////////////////////////Example Of Uses////////////////////////////////////

 <div style="color: <?php echo esc_attr( get_theme_mod( 'my_custom_color', '#000000' ) ); ?>;">
    <?php echo esc_html( get_theme_mod( 'my_custom_text', 'Hello, World!' ) ); ?>
</div>

<?php if ( $image = get_theme_mod( 'my_custom_image' ) ) : ?>
    <img src="<?php echo esc_url( $image ); ?>" alt="Custom Image" />
<?php endif; ?>



//////////////////////////////All Functions Here//////////////////////////////////////


function mytheme_customize_register1( $wp_customize ) {

    // Add a section for the controls
    $wp_customize->add_section( 'mytheme_options_section', array(
        'title'    => __( 'My Theme Options', 'mytheme' ),
        'priority' => 30,
    ) );

    /**
     * TEXT INPUT CONTROL
     */
    $wp_customize->add_setting( 'mytheme_text_setting', array(
        'default'   => __( 'Default Text', 'mytheme' ),
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( 'mytheme_text_control', array(
        'label'    => __( 'Text Input', 'mytheme' ),
        'section'  => 'mytheme_options_section',
        'settings' => 'mytheme_text_setting',
        'type'     => 'text',
    ) );

    /**
     * TEXTAREA CONTROL
     */
    $wp_customize->add_setting( 'mytheme_textarea_setting', array(
        'default'   => __( 'Default Textarea Content', 'mytheme' ),
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( 'mytheme_textarea_control', array(
        'label'    => __( 'Textarea Input', 'mytheme' ),
        'section'  => 'mytheme_options_section',
        'settings' => 'mytheme_textarea_setting',
        'type'     => 'textarea',
    ) );

    /**
     * CHECKBOX CONTROL
     */
    $wp_customize->add_setting( 'mytheme_checkbox_setting', array(
        'default'   => false,
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( 'mytheme_checkbox_control', array(
        'label'    => __( 'Checkbox Input', 'mytheme' ),
        'section'  => 'mytheme_options_section',
        'settings' => 'mytheme_checkbox_setting',
        'type'     => 'checkbox',
    ) );

    /**
     * RADIO BUTTON CONTROL
     */
    $wp_customize->add_setting( 'mytheme_radio_setting', array(
        'default'   => 'option1',
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( 'mytheme_radio_control', array(
        'label'    => __( 'Radio Button Input', 'mytheme' ),
        'section'  => 'mytheme_options_section',
        'settings' => 'mytheme_radio_setting',
        'type'     => 'radio',
        'choices'  => array(
            'option1' => __( 'Option 1', 'mytheme' ),
            'option2' => __( 'Option 2', 'mytheme' ),
            'option3' => __( 'Option 3', 'mytheme' ),
        ),
    ) );

    /**
     * SELECT/DROPDOWN CONTROL
     */
    $wp_customize->add_setting( 'mytheme_select_setting', array(
        'default'   => 'option1',
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( 'mytheme_select_control', array(
        'label'    => __( 'Select Dropdown Input', 'mytheme' ),
        'section'  => 'mytheme_options_section',
        'settings' => 'mytheme_select_setting',
        'type'     => 'select',
        'choices'  => array(
            'option1' => __( 'Option 1', 'mytheme' ),
            'option2' => __( 'Option 2', 'mytheme' ),
            'option3' => __( 'Option 3', 'mytheme' ),
        ),
    ) );

    /**
     * COLOR PICKER CONTROL
     */
    $wp_customize->add_setting( 'mytheme_color_setting', array(
        'default'   => '#000000',
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mytheme_color_control', array(
        'label'    => __( 'Color Picker Input', 'mytheme' ),
        'section'  => 'mytheme_options_section',
        'settings' => 'mytheme_color_setting',
    ) ) );

    /**
     * IMAGE UPLOAD CONTROL
     */
    $wp_customize->add_setting( 'mytheme_image_setting', array(
        'default'   => '',
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'mytheme_image_control', array(
        'label'    => __( 'Image Upload', 'mytheme' ),
        'section'  => 'mytheme_options_section',
        'settings' => 'mytheme_image_setting',
    ) ) );

    /**
     * FILE UPLOAD CONTROL
     */
    $wp_customize->add_setting( 'mytheme_file_setting', array(
        'default'   => '',
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( new WP_Customize_Upload_Control( $wp_customize, 'mytheme_file_control', array(
        'label'    => __( 'File Upload', 'mytheme' ),
        'section'  => 'mytheme_options_section',
        'settings' => 'mytheme_file_setting',
    ) ) );

    /**
     * RANGE SLIDER CONTROL
     */
    $wp_customize->add_setting( 'mytheme_range_setting', array(
        'default'   => '50',
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( 'mytheme_range_control', array(
        'label'    => __( 'Range Slider Input', 'mytheme' ),
        'section'  => 'mytheme_options_section',
        'settings' => 'mytheme_range_setting',
        'type'     => 'range',
        'input_attrs' => array(
            'min'   => 1,
            'max'   => 100,
            'step'  => 1,
        ),
    ) );

    /**
     * DATE/TIME PICKER CONTROL (You'd need custom JS or use a plugin for full date/time functionality)
     */
    $wp_customize->add_setting( 'mytheme_date_setting', array(
        'default'   => date( 'Y-m-d' ), // Default to the current date
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( 'mytheme_date_control', array(
        'label'    => __( 'Date Picker Input', 'mytheme' ),
        'section'  => 'mytheme_options_section',
        'settings' => 'mytheme_date_setting',
        'type'     => 'date',
    ) );

}

add_action( 'customize_register', 'mytheme_customize_register1' );
