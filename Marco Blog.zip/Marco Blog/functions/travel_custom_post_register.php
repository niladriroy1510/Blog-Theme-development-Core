<?php

// Register Custom Post Type for travel
function my_custom_post_Travel() {
    $labels = array(
        'name'               => _x( 'Travel', 'marco' ),
        'singular_name'      => _x( 'Travel', 'marco' ),
        'add_new'            => _x( 'Add New Travel', 'marco' ),
        'add_new_item'       => __( 'Add New Travel' ),
        'edit_item'          => __( 'Edit Travel' ),
        'new_item'           => __( 'New Travel' ),
        'all_items'          => __( 'All Travel' ),
        'view_item'          => __( 'View Travel' ),
        'search_items'       => __( 'Search Travel' ),
        'not_found'          => __( 'No Travel found' ),
        'not_found_in_trash' => __( 'No Travel found in the Trash' ),
        'menu_name'          => 'Travels',
    );
    $args = array(
        'labels'            => $labels,
        'description'       => 'Holds our Travel and Travel specific data',
        'public'            => true,
		'supports'          => array( 'title', 'editor', 'comments', 'excerpt', 'author', 'thumbnail', 'custom-fields', 'revisions' ),
        'has_archive'       => true,
        'rewrite'           => array('slug' => 'Travel'),
        'publicly_queryable' => true,
        'show_ui'           => true,
        'show_in_menu'      => true,
        'show_in_rest'      => false, // To use Gutenberg editor.
        'query_var'         => true,
        'hierarchical'      => false,
        'menu_position'     => null,
        'taxonomies'        => array('category_Travel') // Use the correct taxonomy name here
    );
    register_post_type( 'Travel', $args );
}
add_action( 'init', 'my_custom_post_Travel' );
