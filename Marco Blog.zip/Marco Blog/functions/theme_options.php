<?php

function MarcoBlog_header_social_option( $wp_customize ) {
    // Add a section for the switch
    $wp_customize->add_section( 'my_switch_section1', array(
        'title'    => __( 'Header', 'marco' ),
        'priority' => 30,
    ) );

    // Add setting for the switch 1
    $wp_customize->add_setting( 'social_media_header', array(
        'default'   => 'off', // Default value can be 'on' or 'off'
        'transport' => 'refresh',
    ) );

    // Add the switch control
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'my_switch_control_1', array(
        'label'    => __( 'Header Social', 'marco' ),
        'section'  => 'my_switch_section1',
        'settings' => 'social_media_header',
        'type'     => 'checkbox', // Use checkbox for switch
    ) ) );	
	
	   // Add setting for the switch 2
    $wp_customize->add_setting( 'search_header', array(
        'default'   => 'off', // Default value can be 'on' or 'off'
        'transport' => 'refresh',
    ) );

    // Add the switch control
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'my_switch_control_2', array(
        'label'    => __( 'Header Search', 'marco' ),
        'section'  => 'my_switch_section1',
        'settings' => 'search_header',
        'type'     => 'checkbox', // Use checkbox for switch
    ) ) );	
	
	 // Add setting for the switch 3
    $wp_customize->add_setting( 'header_logo', array(
        'default'   => 'off', // Default value can be 'on' or 'off'
        'transport' => 'refresh',
    ) );

    // Add the switch control
    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'my_switch_control_3', array(
        'label'    => __( 'Header Logo', 'marco' ),
        'section'  => 'my_switch_section1',
        'settings' => 'header_logo',
        'type'     => 'checkbox', // Use checkbox for switch
    ) ) );	

}

add_action( 'customize_register', 'MarcoBlog_header_social_option' );


////////////////////////////////////////////////////////////


function MarcoBlog_customize_register_1( $wp_customize ) {
    // Add a section for custom options
    $wp_customize->add_section( 'my_custom_options', array(
        'title'    => __( 'Theme Options', 'marco' ),
        'priority' => 30,
    ) );

    // Add a setting for a text option
    $wp_customize->add_setting( 'footer_text', array(
        'default'   => '© 2024 - All Rights Reserved',
        'transport' => 'refresh',
    ) );

    // Add a control for the text option
    $wp_customize->add_control( 'my_custom_text_control', array(
        'label'    => __( 'Footer CopyRight Text', 'marco' ),
        'section'  => 'my_custom_options',
        'settings' => 'footer_text',
        'type'     => 'text',
    ) );

    $wp_customize->add_setting( 'footer_bg_color_setting', array(
        'default'   => '#fff',
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mytheme_color_control', array(
        'label'    => __( 'Footer bg Color', 'marco' ),
        'section'  => 'my_custom_options',
        'settings' => 'footer_bg_color_setting',
    ) ) );


    $wp_customize->add_setting( 'footer_copyRight_text_align', array(
        'default'   => 'Left',
        'transport' => 'refresh',
    ) );

    $wp_customize->add_control( 'copyright_select_control', array(
        'label'    => __( 'Copyright Align', 'marco' ),
        'section'  => 'my_custom_options',
        'settings' => 'footer_copyRight_text_align',
        'type'     => 'select',
        'choices'  => array(
            'Left' => __( 'Left', 'marco' ),
            'Right' => __( 'Right', 'marco' ),
        ),
    ) );

}

add_action( 'customize_register', 'MarcoBlog_customize_register_1' );



///////////////////////////////////////////////////////////////////////////
