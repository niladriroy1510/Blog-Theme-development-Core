<?php

// Register Custom Post Type for portfolio
function my_custom_post_portfolio() {
    $labels = array(
        'name'               => _x( 'Portfolio', 'marco' ),
        'singular_name'      => _x( 'Portfolio', 'marco' ),
        'add_new'            => _x( 'Add New Portfolio', 'marco' ),
        'add_new_item'       => __( 'Add New Portfolio' ),
        'edit_item'          => __( 'Edit Portfolio' ),
        'new_item'           => __( 'New Portfolio' ),
        'all_items'          => __( 'All Portfolio' ),
        'view_item'          => __( 'View Portfolio' ),
        'search_items'       => __( 'Search Portfolio' ),
        'not_found'          => __( 'No Portfolio found' ),
        'not_found_in_trash' => __( 'No Portfolio found in the Trash' ),
        'menu_name'          => 'Portfolios',
    );
    $args = array(
        'labels'            => $labels,
        'description'       => 'Holds our Portfolio and Portfolio specific data',
        'public'            => true,
		'supports'          => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'custom-fields', 'revisions' ),
        'has_archive'       => true,
        'rewrite'           => array('slug' => 'Portfolio'),
        'publicly_queryable' => true,
        'show_ui'           => true,
        'show_in_menu'      => true,
        'show_in_rest'      => false, // To use Gutenberg editor.
        'query_var'         => true,
        'hierarchical'      => false,
        'menu_position'     => null,
        'taxonomies'        => array('category_Portfolio') // Use the correct taxonomy name here
    );
    register_post_type( 'Portfolio', $args );
}
add_action( 'init', 'my_custom_post_portfolio' );


 
// Register Custom Taxonomy for Portfolio
function my_taxonomies_Portfolio() {
    $labels = array(
        'name'              => _x( 'Portfolio Categories', 'onum' ),
        'singular_name'     => _x( 'Portfolio Category', 'onum' ),
        'search_items'      => __( 'Search Portfolio Categories' ),
        'all_items'         => __( 'All Portfolio Categories' ),
        'parent_item'       => __( 'Parent Portfolio Category' ),
        'parent_item_colon' => __( 'Parent Portfolio Category:' ),
        'edit_item'         => __( 'Edit Portfolio Category' ),
        'update_item'       => __( 'Update Portfolio Category' ),
        'add_new_item'      => __( 'Add New Portfolio Category' ),
        'new_item_name'     => __( 'New Portfolio Category' ),
        'menu_name'         => __( 'Portfolio Categories' ),
    );
    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
		'show_in_rest'      => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'Portfolio-category' ), // Use the correct rewrite slug
    );
    register_taxonomy( 'category_Portfolio', array('portfolio'), $args );
}
add_action( 'init', 'my_taxonomies_Portfolio', 0 );


//End Custom Post Register Portfolio
