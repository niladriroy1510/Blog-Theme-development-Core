<?php

function ocdi_import_files() {
  return [
    [
      'import_file_name'             => 'Demo Import 1',
      'categories'                   => [ 'Blog', 'Category 2' ],
      'local_import_file'            => trailingslashit( get_template_directory_uri() ) . '/functions/one-click-demo-import/demo-file/demo-1/demo-content.xml',
      'local_import_widget_file'     => trailingslashit( get_template_directory_uri() ) . '/functions/one-click-demo-import/demo-file/demo-1/widgets.json',
      'local_import_customizer_file' => trailingslashit( get_template_directory_uri() ) . '/functions/one-click-demo-import/demo-file/demo-1/customizer.dat',
      /* 'local_import_redux'           => [
        [
          'file_path'   => trailingslashit( get_template_directory() ) . 'ocdi/redux.json',
          'option_name' => 'redux_option_name',
        ],
      ], */
      'import_preview_image_url'     => get_template_directory_uri().'/functions/one-click-demo-import/demo-image/demo1.png',
      'preview_url'                  => 'http://localhost/wp/wp1/',
    ],
	
	/* 
     [
      'import_file_name'             => 'Demo Import 2',
      'categories'                   => [ 'New category', 'Old category' ],
      'local_import_file'            => trailingslashit( get_template_directory() ) . 'functions/one-click-demo-import/demo-file/demo-1/demo-content2.xml',
      'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'functions/one-click-demo-import/demo-file/demo-1/widgets2.json',
      'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'functions/one-click-demo-import/demo-file/demo-1/customizer2.dat',
      'local_import_redux'           => [
        [
          'file_path'   => trailingslashit( get_template_directory() ) . 'ocdi/redux.json',
          'option_name' => 'redux_option_name',
        ],
        [
          'file_path'   => trailingslashit( get_template_directory() ) . 'ocdi/redux2.json',
          'option_name' => 'redux_option_name_2',
        ],
      ],
      'import_preview_image_url'     => 'http://www.your_domain.com/ocdi/preview_import_image2.jpg',
      'preview_url'                  => 'http://www.your_domain.com/my-demo-2',
    ], 
	 */
	
  ];
}
add_filter( 'ocdi/import_files', 'ocdi_import_files' );


//Before Import Custom Code Execution
	
function ocdi_before_content_import( $selected_import ) {
    if ( 'Demo Import 1' === $selected_import['import_file_name'] ) {
        // Here you can do stuff for the "Demo Import 1" before the content import starts.
        echo "before import 1";
    }
    else {
        // Here you can do stuff for all other imports before the content import starts.
        echo "before import 2";
    }
}
add_action( 'ocdi/before_content_import', 'ocdi_before_content_import' );



//After Import Custom Code Execution

function ocdi_after_import_setup() {
  // Assign menus to their locations.
    $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
  
    set_theme_mod( 'nav_menu_locations', [
            'main-menu' => $main_menu->term_id, // replace 'main-menu' here with the menu location identifier from register_nav_menu() function in your theme.
        ]
    );
  
  // Get the front page.
  $front_page = get_posts(
    [
      'post_type'              => 'page',
      'title'                  => 'Home',
      'post_status'            => 'all',
      'numberposts'            => 1,
      'update_post_term_cache' => false,
      'update_post_meta_cache' => false,
    ]
  );
 
  if ( ! empty( $front_page ) ) {
    update_option( 'page_on_front', $front_page[0]->ID );
  }
 
  // Get the blog page.
  $blog_page = get_posts(
    [
      'post_type'              => 'page',
      'title'                  => 'Post',
      'post_status'            => 'all',
      'numberposts'            => 1,
      'update_post_term_cache' => false,
      'update_post_meta_cache' => false,
    ]
  );
 
  if ( ! empty( $blog_page ) ) {
    update_option( 'page_for_posts', $blog_page[0]->ID );
  }
 
  if ( ! empty( $blog_page ) || ! empty( $front_page ) ) {
    update_option( 'show_on_front', 'page' );
  }
}
add_action( 'ocdi/after_import', 'ocdi_after_import_setup' );


//How to handle different after import custom code executions depending on which predefined demo was imported?

	
function ocdi_after_import( $selected_import ) {
    echo "This will be displayed on all after imports!";
 
    if ( 'Demo Import 1' === $selected_import['import_file_name'] ) {
        echo "This will be displayed only on after import if user selects Demo Import 1";
 
        // Set logo in customizer
        set_theme_mod( 'logo_img', get_template_directory_uri() . '/assets/images/logo1.png' );
    }
    elseif ( 'Demo Import 2' === $selected_import['import_file_name'] ) {
        echo "This will be displayed only on after import if user selects Demo Import 2";
 
        // Set logo in customizer
        set_theme_mod( 'logo_img', get_template_directory_uri() . '/assets/images/logo2.png' );
    }
}
add_action( 'ocdi/after_import', 'ocdi_after_import' );


//Set Recommended Plugins based on the Selected Demo


function ocdi_register_plugins( $plugins ) {
 
  // Required: List of plugins used by all theme demos.
  $theme_plugins = [
    [ // A WordPress.org plugin repository example.
      'name'     => 'Advanced Custom Fields', // Name of the plugin.
      'slug'     => 'advanced-custom-fields', // Plugin slug - the same as on WordPress.org plugin repository.
      'required' => true,                     // If the plugin is required or not.
    ],
    [ // A locally theme bundled plugin example.
      'name'     => 'Elementor Pro',
      'slug'     => 'elementor-pro',         // The slug has to match the extracted folder from the zip.
      'source'   => get_template_directory_uri() . '/TGM-Plugin-Activation-2.6.1/plugins/elementor-pro.zip',
      'required' => true,
    ],
	
	[
      'name'        => 'Form Craft',
      'description' => 'Form-Craft',
      'slug'        => 'self-hosted-plugin',  // The slug has to match the extracted folder from the zip.
      'source'      => get_template_directory_uri() .  '/TGM-Plugin-Activation-2.6.1/plugins/Form Craft.zip',
      'required' => true,
    ],
	
    /* [
      'name'        => 'Self Hosted Plugin',
      'description' => 'This is the plugin description',
      'slug'        => 'self-hosted-plugin',  // The slug has to match the extracted folder from the zip.
      'source'      => 'https://example.com/my-site/self-hosted-plugin.zip',
      'preselected' => true,
    ], */
  ];
 
  // Check if user is on the theme recommeneded plugins step and a demo was selected.
  if (
    isset( $_GET['step'] ) &&
    $_GET['step'] === 'import' &&
    isset( $_GET['import'] )
  ) {
 
    // Adding one additional plugin for the first demo import ('import' number = 0).
    if ( $_GET['import'] === '0' ) {
      $theme_plugins[] = [
        'name'     => 'Elementor',
        'slug'     => 'elementor',
        'required' => true,
      ];
 
     /*  $theme_plugins[] = [
        'name'     => 'SiteOrigin Widgets Bundle',
        'slug'     => 'so-widgets-bundle',
        'required' => true,
      ]; */
    }
 
    // List of all plugins only used by second demo import [overwrite the list] ('import' number = 1).
    if ( $_GET['import'] === '1' ) {
      $theme_plugins = [
        [
          'name'     => 'Advanced Custom Fields',
          'slug'     => 'advanced-custom-fields',
          'required' => true,
        ],
       /*  [
          'name'     => 'Portfolio Post Type',
          'slug'     => 'portfolio-post-type',
          'required' => false,
        ], */
      ];
    }
  }
 
  return array_merge( $plugins, $theme_plugins );
}
add_filter( 'ocdi/register_plugins', 'ocdi_register_plugins' );