<?php

// Disable WordPress cache-related cookies
/* function disable_wp_cache_cookies() {
    // Unset cache-related cookies
    if ( isset($_COOKIE['wp-settings-' . COOKIEHASH]) ) {
        setcookie('wp-settings-' . COOKIEHASH, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
    }
    if ( isset($_COOKIE['wp-settings-time-' . COOKIEHASH]) ) {
        setcookie('wp-settings-time-' . COOKIEHASH, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
    }
}
add_action( 'init', 'disable_wp_cache_cookies' ); */

// Disable comment author cookies
/* function disable_comment_author_cookies() {
    if ( isset($_COOKIE['comment_author_' . COOKIEHASH]) ) {
        setcookie('comment_author_' . COOKIEHASH, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
    }
    if ( isset($_COOKIE['comment_author_email_' . COOKIEHASH]) ) {
        setcookie('comment_author_email_' . COOKIEHASH, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
    }
    if ( isset($_COOKIE['comment_author_url_' . COOKIEHASH]) ) {
        setcookie('comment_author_url_' . COOKIEHASH, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
    }
}
add_action( 'init', 'disable_comment_author_cookies' ); */

// Prevent caching for logged-in users
/* function no_cache_for_logged_in_users() {
    if ( is_user_logged_in() ) {
        nocache_headers();
    }
}
add_action( 'init', 'no_cache_for_logged_in_users' ); */

// Disable WP Super Cache cookie
/* function disable_wp_super_cache_cookie() {
    if ( isset($_COOKIE['wpSGCacheBypass']) ) {
        setcookie('wpSGCacheBypass', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
    }
}
add_action( 'init', 'disable_wp_super_cache_cookie' ); */












/////////////// Disable Gutenberg///////////////

// Disable Gutenberg for all post types
//add_filter('use_block_editor_for_post', '__return_false', 10);
//add_filter('use_block_editor_for_post_type', '__return_false', 10);

// Disable Gutenberg for widgets
//add_filter( 'use_widgets_block_editor', '__return_false' );



// Disable Gutenberg for specific post types
	/* 
	function disable_gutenberg_for_specific_post_types($is_enabled, $post_type) {
		if ($post_type === 'post' || $post_type === 'page') {
			return false; // Disable for posts and pages
		}
		return $is_enabled; // Keep it enabled for other post types
	}
	add_filter('use_block_editor_for_post_type', 'disable_gutenberg_for_specific_post_types', 10, 2);
*/


/////////////// Disable Gutenberg///////////////



function custom_image_sizes() {
    add_image_size( 'portfolio-Image-size', 270, 260, true ); // Width 270px, Height 260px, hard crop
}
add_action( 'after_setup_theme', 'custom_image_sizes' );







// Add theme support for custom logo
function MarcoBlog_logo_setup() {
	
	add_theme_support('post-thumbnails'); // theme post image support
	add_theme_support('title-tag'); //Theme title support
	
    add_theme_support( 'custom-logo', array(
        'height'      => 50,  // Set the desired height of the logo
        'width'       => 98,  // Set the desired width of the logo
        'flex-height' => true, // Allow flexible height
        'flex-width'  => true, // Allow flexible width
    ) );
	
}
add_action( 'after_setup_theme', 'MarcoBlog_logo_setup' );


//Css and jquery call

function MarcoBlog_enqueue_assets() {
    // Enqueue CSS
    wp_enqueue_style('MarcoBlog-style', get_stylesheet_uri());
    wp_enqueue_style('MarcoBlog-bootstrap-css', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
    wp_enqueue_style('MarcoBlog-carousel-css', get_template_directory_uri() . '/assets/css/owl.carousel.css');
    wp_enqueue_style('MarcoBlog-magnific-css', get_template_directory_uri() . '/assets/css/magnific-popup.css');
    wp_enqueue_style('MarcoBlog-animate-css', get_template_directory_uri() . '/assets/css/animate.min.css');
    wp_enqueue_style('MarcoBlog-iconic-css', get_template_directory_uri() . '/assets/css/material-design-iconic-font.min.css');
    wp_enqueue_style('MarcoBlog-slicknav-css', get_template_directory_uri() . '/assets/css/slicknav.min.css');
    wp_enqueue_style('MarcoBlog-responsive-css', get_template_directory_uri() . '/assets/css/responsive.css');

    // Enqueue jQuery and a custom script
    wp_enqueue_script('jquery');
    wp_enqueue_script('MarcoBlog-popper-js', get_template_directory_uri() . '/assets/js/popper.min.js', array('jquery'), null, true);
    wp_enqueue_script('MarcoBlog-bootstrap-js', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), null, true);
    wp_enqueue_script('MarcoBlog-carousel-js', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array('jquery'), null, true);
    wp_enqueue_script('MarcoBlog-slicknav-js', get_template_directory_uri() . '/assets/js/jquery.slicknav.min.js', array('jquery'), null, true);
    wp_enqueue_script('MarcoBlog-magnific-js', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js', array('jquery'), null, true);
    wp_enqueue_script('MarcoBlog-wow-js', get_template_directory_uri() . '/assets/js/wow.min.js', array('jquery'), null, true);
    wp_enqueue_script('MarcoBlog-isotope-js', get_template_directory_uri() . '/assets/js/isotope.pkgd.min.js', array('jquery'), null, true);
    wp_enqueue_script('MarcoBlog-masonary-js', get_template_directory_uri() . '/assets/js/masonary.js', array('jquery'), null, true);
    wp_enqueue_script('MarcoBlog-active-js', get_template_directory_uri() . '/assets/js/active.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'MarcoBlog_enqueue_assets');


/////////////////// Register Widget Areas/////////////

function MarcoBlog_widgets_init() {
    
    register_sidebar( array(
        'name'          => __( 'Post Sidebar Widget Area 1', 'marco' ),
        'id'            => 'post-side-bar-1',
        'description'   => __( 'Add widgets here to appear in your post sidebar.', 'marco' ),
        'before_widget' => ' <div class="home-masonry-right">',
        'after_widget'  => ' </div>',
        'before_title'  => '<h3 class="home-masonry-right-title">',
        'after_title'   => '</h3>',
    ) );
	
	 register_sidebar( array(
        'name'          => __( 'Post Sidebar Widget Area 2', 'marco' ),
        'id'            => 'post-side-bar-2',
        'description'   => __( 'Add widgets here to appear in your post sidebar.', 'marco' ),
        'before_widget' => '<div class="home-masonry-right cta-2">',
        'after_widget'  => '</div>',
        'before_title'  => ' <h3 class="home-masonry-right-title">',
        'after_title'   => '</h3>',
    ) );
	
	 register_sidebar( array(
        'name'          => __( 'Post Sidebar Widget Area 3', 'marco' ),
        'id'            => 'post-side-bar-3',
        'description'   => __( 'Add widgets here to appear in your post sidebar.', 'marco' ),
        'before_widget' => ' <div class="home-masonry-right cta-3">',
        'after_widget'  => '</div>',
        'before_title'  => ' <h3 class="home-masonry-right-title">',
        'after_title'   => '</h3>',
    ) );
	
	 register_sidebar( array(
        'name'          => __( 'Post Sidebar Widget Area 4', 'marco' ),
        'id'            => 'post-side-bar-4',
        'description'   => __( 'Add widgets here to appear in your post sidebar.', 'marco' ),
        'before_widget' => '<div class="home-masonry-right ctt cta-4">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );
	
	register_sidebar( array(
        'name'          => __( 'Post Sidebar Widget Area 5', 'marco' ),
        'id'            => 'post-side-bar-5',
        'description'   => __( 'Add widgets here to appear in your post sidebar.', 'marco' ),
        'before_widget' => ' <div class="standard-post-search">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );
	
	register_sidebar( array(
        'name'          => __( 'Footer Area 1', 'marco' ),
        'id'            => 'footer-1',
        'description'   => __( 'Add widgets here to appear in your footer.', 'marco' ),
        'before_widget' => '<div class="footer-logo">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );
	
	register_sidebar( array(
        'name'          => __( 'Footer Area 2', 'marco' ),
        'id'            => 'footer-2',
        'description'   => __( 'Add widgets here to appear in your footer.', 'marco' ),
        'before_widget' => ' <div class="mainmenu footer-menu text-right">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );

	register_sidebar( array(
        'name'          => __( 'Footer Area 3', 'marco' ),
        'id'            => 'footer-3',
        'description'   => __( 'Add widgets here to appear in your footer.', 'marco' ),
        'before_widget' => '<div class="home-footer-social-left">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );
	
	register_sidebar( array(
        'name'          => __( 'Footer Area 4', 'marco' ),
        'id'            => 'footer-4',
        'description'   => __( 'Add widgets here to appear in your footer.', 'marco' ),
        'before_widget' => '<div class="home-footer-social-right text-right">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );

}
add_action( 'widgets_init', 'MarcoBlog_widgets_init' );


/////////////////// Register Widget Areas/////////////



// Register navigation menus

function MarcoBlog_menus() {
    register_nav_menus(
        array(
            'header-menu' => __('Header Menu', 'marco'),
            'footer-menu' => __('Footer Menu', 'marco')
        )
    );
}
add_action( 'init', 'MarcoBlog_menus' );


// //////////////////////////////////////////////////////////////////////////////////////////
// ////////////////////        Include Theme Files                 //////////////////////////
// //////////////////////////////////////////////////////////////////////////////////////////

require get_theme_file_path('functions/social.php');
require get_theme_file_path('functions/theme_options.php');
//require get_theme_file_path('functions/Demo_Customizer _options.php');
require get_theme_file_path('functions/portfolio_custom_register.php');
//require get_theme_file_path('functions/Page_Options_functions.php');
require get_theme_file_path('functions/travel_custom_post_register.php');

// Required install plugin for this theme.

require get_theme_file_path('functions/TGM-Plugin-Activation-2.6.1/class-tgm-plugin-activation.php');
require get_theme_file_path('functions/TGM-Plugin-Activation-2.6.1/required-install-plugin.php');

//Functions for custom field page
require get_theme_file_path('functions/Custom-field/custom-field-page.php');
//One Click demo Import
require get_theme_file_path('functions/one-click-demo-import/one-click.demo-import.php');