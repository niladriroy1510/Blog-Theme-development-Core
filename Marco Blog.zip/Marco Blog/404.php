<?php get_header(); ?>
<!-- gallery Area start-->
<div class="gallery-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title-area text-center">
                   Sorry!! Something Went Wrong!!!
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 wow fadeInLeft text-center">
                <div class="standard-post-left">
				<div class="standard-single-post">
                        <div class="standard-post-img">
							<img src="<?php bloginfo('template_url'); ?>/assets/img/error.png" alt="404 Image"/>
						</div>
                        <div class="standart-post-text">
                            <h3>404 Page Not Found</h3>
                        </div>
                        <div class="standard-post-social-icon">
                         <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="read-more-btn">Go Back to Home</a>
                    </div>
                </div>		
    </div>
</div>

</div>
</div>
</div>
<!-- gallery Area end-->


<?php get_footer(); ?>