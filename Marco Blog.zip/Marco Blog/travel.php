<?php
/*
    Template Name: Travel Page
*/
get_header();
?>

<!-- gallery Area start -->
<div class="gallery-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title-area text-center">
                    <h1><?php the_title(); ?></h1>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 wow fadeInLeft">
                <div class="standard-post-left">
                    <?php
                    // Query for custom posts
                    $travel_custom_posts = new WP_Query(array(
                        'post_type'      => 'travel',
                        'posts_per_page' => 20,
                    ));

                    if ($travel_custom_posts->have_posts()) :
                        while ($travel_custom_posts->have_posts()) : $travel_custom_posts->the_post();
                    ?>
                        <div class="standard-single-post">
                            <div class="standard-post-img">
                                <a href="<?php the_permalink(); ?>">
                                    
									<?php if ( has_post_thumbnail() ) : ?>
										<div class="custom-post-thumbnail">
											<?php the_post_thumbnail('full', array('class' => 'img-responsive')); ?>
										</div>
									<?php endif; ?>
									
									
                                </a>
                            </div>
                            <div class="standard-post-text">
                                <h3><?php the_title(); ?></h3>
                                <span class="standard-post-meta">
                                    <span class="post-cta11"><i class="zmdi zmdi-account"></i> <?php the_author(); ?></span>
                                    <span class="post-cta22"><i class="zmdi zmdi-alarm"></i> <?php the_time("g:i A"); ?> - <?php the_time("j F, Y"); ?></span>
                                </span>
                                <p><?php the_excerpt(); ?></p>
                            </div>
                            <div class="standard-post-social-icon">
                                <a href="<?php the_permalink(); ?>" class="read-more-btn">Read more</a>
                                <span class="social-cta-right">
                                    <span class="share-cta">Share:</span>
                                    <?php
                                    // Get current post URL and title
                                    $post_url = urlencode(get_permalink());
                                    $post_title = urlencode(get_the_title());
                                    ?>
                                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $post_url; ?>" target="_blank"><i class="zmdi zmdi-facebook"></i></a>
                                    <a href="https://twitter.com/intent/tweet?url=<?php echo $post_url; ?>&text=<?php echo $post_title; ?>" target="_blank"><i class="zmdi zmdi-twitter"></i></a>
                                    <a href="https://plus.google.com/share?url=<?php echo $post_url; ?>" target="_blank"><i class="zmdi zmdi-google-plus"></i></a>
                                    <span class="comment-cta32"><i class="zmdi zmdi-comment"></i> <?php comments_number(); ?></span>
                                </span>
                            </div>
                        </div>
                    <?php
                        endwhile;
                    else :
                        echo '<p>No Travel custom posts found.</p>';
                    endif;

                    // Reset post data after custom query
                    wp_reset_postdata();
                    ?>
                </div>
                <div class="single-post-pagination">
                    <!-- Pagination can be added here if needed -->
                </div>
            </div>
            <?php get_sidebar(); ?>
        </div>
    </div>
</div>
<!-- gallery Area end -->

<?php get_footer(); ?>
