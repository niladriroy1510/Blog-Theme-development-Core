
<?php 

	$footer_top = get_post_meta(get_the_ID(), 'footer_top', true); 
	$footer_text = get_post_meta(get_the_ID(), 'footer_text', true); 

?>

<?php

	if ($footer_text) {
		echo '<marquee><h2 class="page-subtitle">' . esc_html($footer_text) . '</h2></marquee>';
	}

?>


<?php if ($footer_top) { ?>

<!-- home masonry bottom Start-->
<div class="home-masonry-bottom-area wow fadeInUp">
<div class="home-masonry-bottom">
<div class="home-masonry-bottom-single">
<a href="assets/img/home-masonry-bottom-img-1-.jpg" class="masonry-light-box"><img src="<?php bloginfo('template_url'); ?>/assets/img/home-masonry-bottom-img-1-.jpg" alt=""></a>
</div>
<div class="home-masonry-bottom-single">
<a href="assets/img/home-masonry-bottom-img-2.jpg" class="masonry-light-box"><img src="<?php bloginfo('template_url'); ?>/assets/img/home-masonry-bottom-img-2.jpg" alt=""></a>
</div>
<div class="home-masonry-bottom-single">
<a href="assets/img/home-masonry-bottom-big-img.jpg" class="masonry-light-box"><img src="<?php bloginfo('template_url'); ?>/assets/img/home-masonry-bottom-big-img.jpg" alt=""></a>
</div>
<div class="home-masonry-bottom-single">
<a href="assets/img/home-masonry-bottom-img-6.jpg" class="masonry-light-box"><img src="<?php bloginfo('template_url'); ?>/assets/img/home-masonry-bottom-img-6.jpg" alt=""></a>
</div>
<div class="home-masonry-bottom-single">
<a href="assets/img/home-masonry-bottom-cta-img.jpg" class="masonry-light-box"><img src="<?php bloginfo('template_url'); ?>/assets/img/home-masonry-bottom-cta-img.jpg" alt=""></a>
</div>
<div class="home-masonry-bottom-single">
<a href="assets/img/home-masonry-bottom-img-7.jpg" class="masonry-light-box"><img src="<?php bloginfo('template_url'); ?>/assets/img/home-masonry-bottom-img-7.jpg" alt=""></a>
</div>
<div class="home-masonry-bottom-single">
<a href="assets/img/home-masonry-bottom-img-8.jpg" class="masonry-light-box"><img src="<?php bloginfo('template_url'); ?>/assets/img/home-masonry-bottom-img-8.jpg" alt=""></a>
</div>
<div class="home-masonry-bottom-single">
<a href="assets/img/home-masonry-bottom-img-4.jpg" class="masonry-light-box"><img src="<?php bloginfo('template_url'); ?>/assets/img/home-masonry-bottom-img-4.jpg" alt=""></a>
</div>
<div class="home-masonry-bottom-single">
<a href="assets/img/home-masonry-bottom-img-10.jpg" class="masonry-light-box"><img src="<?php bloginfo('template_url'); ?>/assets/img/home-masonry-bottom-img-10.jpg" alt=""></a>
</div>


<div class="masonry-bottom-overlay">
<a href="#" class="masonry-bottom-overlay-title">
    <h3>Follow us Instagram</h3>
</a>
</div>



</div>
</div>


	<?php } ?>



<!-- home masonry bottom End-->


<!-- home footer menu start-->
<?php $color_footer_bg = get_theme_mod( 'footer_bg_color_setting', '#fff' ); ?>

<div style="background-color:<?php echo "$color_footer_bg"; ?>"; class="home-footer-area">


<div class="container">
<div class="row">

<div class="col-md-3">
		<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
			<div id="sidebar-widget-area">
				<?php dynamic_sidebar( 'footer-1' ); ?>
			</div>
		<?php endif; ?>

			<?php if ( get_theme_mod( 'header_logo', 'off' ) == 'on' ) { ?>
				
				<div class="logo">
					<?php
						if ( function_exists( 'the_custom_logo' ) ) {
							the_custom_logo();
						} else {
							// Fallback if no logo is set, e.g., display site name
							echo '<h1>' . get_bloginfo( 'name' ) . '</h1>';
						}
					?>
				</div>

			<?php } else { ?>

				<?php echo '<h1>' . get_bloginfo( 'name' ) . '</h1>'; ?>

			<?php } ?>
</div>

<div class="col-md-9">
	<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
		<div id="sidebar-widget-area">
			<?php dynamic_sidebar( 'footer-2' ); ?>
		</div>
	<?php endif; ?>
</div>
</div>

<hr>

<div class="home-footer-social-area">
<div class="row">

<?php
	$select_value_copy = get_theme_mod( 'footer_copyRight_text_align', 'left' );
	
?>
    <div style="text-align:<?php echo $select_value_copy; ?>; " class="col-md-6 col-7">
		<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
			<div id="sidebar-widget-area">
				<?php dynamic_sidebar( 'footer-3' ); ?>
			</div>
		<?php endif; ?>
		
		<?php echo esc_html( get_theme_mod( 'footer_text', 'Default Text' ) ); ?>

    </div>
	
    <div class="col-md-6 col-5">
		<?php if ( is_active_sidebar( 'footer-4' ) ) : ?>
			<div id="sidebar-widget-area">
				<?php dynamic_sidebar( 'footer-4' ); ?>
			</div>
		<?php endif; ?>
		
		<div class="header-social-icon">
		<div class="social-links">
			<?php if ( get_theme_mod( 'facebook_link' ) ) : ?>
				<a href="<?php echo esc_url( get_theme_mod( 'facebook_link' ) ); ?>" target="_blank">
					<i class="zmdi zmdi-facebook"></i>
				</a>
			<?php endif; ?>

			<?php if ( get_theme_mod( 'twitter_link' ) ) : ?>
				<a href="<?php echo esc_url( get_theme_mod( 'twitter_link' ) ); ?>" target="_blank">
					<i class="zmdi zmdi-twitter"></i>
				</a>
			<?php endif; ?>

			<?php if ( get_theme_mod( 'instagram_link' ) ) : ?>
				<a href="<?php echo esc_url( get_theme_mod( 'instagram_link' ) ); ?>" target="_blank">
					<i class="zmdi zmdi-instagram"></i>
				</a>
			<?php endif; ?>
			
			<?php if ( get_theme_mod( 'linkedin_link' ) ) : ?>
				<a href="<?php echo esc_url( get_theme_mod( 'linkedin_link' ) ); ?>" target="_blank">
					<i class="zmdi zmdi-linkedin"></i>
				</a>
			<?php endif; ?>


			</div>	
		</div>

    </div>
</div>
</div>
</div>
</div>

<?php wp_footer(); ?>
</body>
</html>