<?php

/*
Template Name: Home Page
*/

 get_header(); ?>

        <!-- Welcome Area start-->
        <div class="welcome-area wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="welcome-slide">
                         
				 <?php
                    // Query for custom posts
                    $portfolio_custom_posts = new WP_Query(array(
                        'post_type'      => 'Portfolio',
                        'posts_per_page' => 20,
                    ));

                    if ($portfolio_custom_posts->have_posts()) :
                        while ($portfolio_custom_posts->have_posts()) : $portfolio_custom_posts->the_post();
                ?>

							<div class="welcome-single-slide">                              
									<?php if ( has_post_thumbnail() ) : ?>
										<div class="custom-post-thumbnail">
											<?php the_post_thumbnail('portfolio-Image-size', array('class' => 'img-responsive')); ?>
										</div>
									<?php endif; ?>									
                                <div class="slider-text">
                                    <h3><?php the_title(); ?></h3>
                                    <span class="slide-title">
									<a href="#" class="slide-btn global-hvr">
									
										<?php
											// Get custom taxonomy terms for the current post in the 'category_Portfolio' taxonomy
											$terms = get_the_terms( get_the_ID(), 'category_Portfolio' );

											if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
												foreach ( $terms as $term ) {
													echo '<span class="category-name">' . esc_html( $term->name ) . '</span> ';
												}
											} else {
												echo '<p>No categories assigned.</p>';
											}
										?>

									</a>
									<span class="slide-title-right"> <i class="zmdi zmdi-time"></i> <?php the_time("j F, Y"); ?> <i class="zmdi zmdi-comment"></i><?php echo get_comments_number(); ?></span></span>
                                   
								   <?php
										// Get the full content
										$content = get_the_content();

										// Limit the content to 40 words
										$limited_content = wp_trim_words($content, 20, '...'); // Adjust the word count and "read more" text as desired

										// Display the limited content
										echo '<p>' . $limited_content . '</p>';
									?>

                                </div>
                            </div>
								
								<?php
										endwhile;
									else :
										echo '<p>No Portfolio posts found.</p>';
									endif;

									// Reset post data after custom query
									wp_reset_postdata();
								?>
							
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Welcome Area End-->
		
		
        <!-- home masonry start-->
        <div class="home-masonry-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 wow fadeInLeft">
                        <div class="home-masonry-active">
                           

							<?php
								// Get the current page, default to 1 if not set
								$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

								// Query for custom posts
								$post_custom_posts = new WP_Query(array(
									'post_type'      => 'post',
									'posts_per_page' => 10,
									'paged'          => $paged, // Enable pagination awareness
								));

								if ($post_custom_posts->have_posts()) :
									while ($post_custom_posts->have_posts()) : $post_custom_posts->the_post();
							?>


						   <div class="masonry-margin">
                                <div class="home-masonry-single">
                                    <a href="#" class="home-masonry-img">
                                        
									<?php if ( has_post_thumbnail() ) : ?>
										<div class="custom-post-thumbnail">
											<?php the_post_thumbnail('full', array('class' => 'img-responsive')); ?>
										</div>
									<?php endif; ?>			
										
                                    </a>
                                    <div class="home-masonry-title">
                                        <h3><a href="#"><?php the_title(); ?></a></h3>
                                        <h4><img src="assets/img/home-masonry-dot-1.png" alt=""><span><?php the_time("j F, Y"); ?></span><img src="assets/img/home-masonry-dot-1.png" alt=""></h4>
                                        <p><?php the_excerpt(); ?></p>
                                    </div>
                                    <div class="home-masonry-social">
                                        <span class="home-masonry-social-left"><a href="#"><i class="zmdi zmdi-comment"></i></a><?php echo get_comments_number(); ?> <span><a href="#"><i class="zmdi zmdi-favorite-outline"></i></a>35</span></span>
										<span class="home-masonry-social-right">
											   
												<?php
													// Get the current post URL and title
													$post_url = urlencode(get_permalink());
													$post_title = urlencode(get_the_title());
												?>
												
												<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $post_url; ?>" target="_blank">
													<i class="zmdi zmdi-facebook"></i>
												</a>
												<a href="https://twitter.com/intent/tweet?url=<?php echo $post_url; ?>&text=<?php echo $post_title; ?>" target="_blank">
													<i class="zmdi zmdi-twitter"></i>
												</a>
												
												<a href="https://plus.google.com/share?url=<?php echo $post_url; ?>" target="_blank">
													<i class="zmdi zmdi-google-plus"></i>
												</a>
										</span>
                                    </div>
                                </div>
							
                        </div>
						
						
							<div class="home-pagination text-right">
								<nav aria-label="Page">
									<?php
									if ($post_custom_posts->max_num_pages > 1) :
										$pagination_args = array(
											'base'         => str_replace(99999, '%#%', esc_url(get_pagenum_link(99999))),
											'format'       => '?paged=%#%',
											'current'      => max(1, get_query_var('paged')),
											'total'        => $post_custom_posts->max_num_pages, // Use max pages from the custom query
											'prev_text'    => '<i class="zmdi zmdi-chevron-left"></i>',
											'next_text'    => '<i class="zmdi zmdi-chevron-right"></i>',
											'type'         => 'array',
											'end_size'     => 1,
											'mid_size'     => 2,
										);

										$pages = paginate_links($pagination_args);

										if (is_array($pages)) :
											echo '<ul class="pagination">';
											foreach ($pages as $page) {
												$active = strpos($page, 'current') !== false ? ' active' : '';
												echo '<li class="page-item' . $active . '">' . str_replace('page-numbers', 'page-link', $page) . '</li>';
											}
											echo '</ul>';
										endif;
									endif;
									?>
								</nav>
							</div>

					
							<?php
								endwhile;
								else :
									echo '<p>No Portfolio posts found.</p>';
								endif;

								// Reset post data after custom query
								wp_reset_postdata();
						
							?>
							
                    </div>
                    </div>
                    
					<?php get_sidebar(); ?>
					
                </div>
            </div>
        </div>

 <?php get_footer(); ?>