<!DOCTYPE html>
<html lang="zxx">
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<?php wp_head(); ?>
    </head>
    <body>
        <!-- Page preloader -->
        <div id="loading">
            <div id="preloader">
                <span></span>
                <span></span>
            </div>
        </div>
        <!-- header Area Start-->
        <div class="header-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-6">
                       
					<?php if ( get_theme_mod( 'search_header', 'off' ) == 'on' ) : ?>
					  
					  <div class="search-bar-left">
                            <span class="search-left">
								<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
									<input type="search" class="search-field" placeholder="Type here..." value="<?php echo get_search_query(); ?>" name="s" title="Search for:">
									<i class="zmdi zmdi-search"></i>
								</form>
							</span>
							
                        </div>
						
					<?php endif; ?>	
						
                    </div>
                    <div class="col-md-6 col-6 text-center">
                        
						<?php if ( get_theme_mod( 'header_logo', 'off' ) == 'on' ) { ?>
							
							<div class="logo">
								<?php
									if ( function_exists( 'the_custom_logo' ) ) {
										the_custom_logo();
									} else {
										// Fallback if no logo is set, e.g., display site name
										echo '<h1>' . get_bloginfo( 'name' ) . '</h1>';
									}
								?>
							</div>
						
						<?php } else { ?>
						
							<?php echo '<h1>' . get_bloginfo( 'name' ) . '</h1>'; ?>
						
						<?php } ?>
						
						
						
						
						
                    </div>
                    <div class="col-md-3 col-12">
                        
					<?php if ( get_theme_mod( 'social_media_header', 'off' ) == 'on' ) : ?>
								
						<div class="header-social-icon">
						
							<div class="social-links">
								<?php if ( get_theme_mod( 'facebook_link' ) ) : ?>
									<a href="<?php echo esc_url( get_theme_mod( 'facebook_link' ) ); ?>" target="_blank">
										<i class="zmdi zmdi-facebook"></i>
									</a>
								<?php endif; ?>

								<?php if ( get_theme_mod( 'twitter_link' ) ) : ?>
									<a href="<?php echo esc_url( get_theme_mod( 'twitter_link' ) ); ?>" target="_blank">
										<i class="zmdi zmdi-twitter"></i>
									</a>
								<?php endif; ?>

								<?php if ( get_theme_mod( 'instagram_link' ) ) : ?>
									<a href="<?php echo esc_url( get_theme_mod( 'instagram_link' ) ); ?>" target="_blank">
										<i class="zmdi zmdi-instagram"></i>
									</a>
								<?php endif; ?>
								
								<?php if ( get_theme_mod( 'linkedin_link' ) ) : ?>
									<a href="<?php echo esc_url( get_theme_mod( 'linkedin_link' ) ); ?>" target="_blank">
										<i class="zmdi zmdi-linkedin"></i>
									</a>
								<?php endif; ?>

								<!-- Add more social icons as needed -->
							</div>
							
                        </div>
						
					<?php endif; ?>	
						
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="responsive_menu"></div>
                <div class="mainmenu homemenu">
						<?php
							// Display the header menu
							wp_nav_menu( array(
								'theme_location' => 'header-menu',
								'container'      => 'nav',
								'container_class' => 'main-navigation',
								'menu_class'     => '',
							) );
						?>

				</div>
            </div>
        </div>
    </div>
</div>
<!-- Header Area End-->