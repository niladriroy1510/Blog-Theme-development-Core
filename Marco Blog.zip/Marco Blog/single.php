<?php get_header(); ?>
<!-- gallery Area start-->
<div class="gallery-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title-area text-center">
					<?php $page_title = get_the_title(); ?>
                    <h3> <?php echo $page_title; ?></h3>
						<?php $home_url = home_url(); ?>
                    <h4><a href="<?php echo $home_url; ?>">Home / </a><a href="gallery.html"> <?php echo $page_title; ?></a></h4>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 wow fadeInLeft">
                <div class="standard-post-left">
                 
				 <?php	
				 
						if ( have_posts() ) :
						while ( have_posts() ) : the_post();
						
				 ?>
				 
				 
				 
				<div class="standard-single-post">
                        <div class="standard-post-img">
							<?php the_post_thumbnail('full', array('class' => 'img-responsive' )); ?>
						</div>
                        <div class="standart-post-text">
                            <h3><?php the_title(); ?></h3>
                            <span class="standard-post-meta"><span class="post-cta11"><i class="zmdi zmdi-account"></i> <?php print get_the_author(); ?></span> <span class="post-cta22"><i class="zmdi zmdi-alarm"></i><?php the_time("g:i A"); ?> - <?php the_time("j F, Y"); ?></span></span>
                            <p><?php the_content(); ?></p>
                        </div>
                        <div class="standard-post-social-icon">
						  <span class="social-cta-right">
						  <span class="share-cta">Share:</span>
						  
							<?php
								// Get the current post URL and title
								$post_url = urlencode(get_permalink());
								$post_title = urlencode(get_the_title());
							?>
							
							<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $post_url; ?>" target="_blank">
								<i class="zmdi zmdi-facebook"></i>
							</a>
							<a href="https://twitter.com/intent/tweet?url=<?php echo $post_url; ?>&text=<?php echo $post_title; ?>" target="_blank">
								<i class="zmdi zmdi-twitter"></i>
							</a>
							
							<a href="https://plus.google.com/share?url=<?php echo $post_url; ?>" target="_blank">
								<i class="zmdi zmdi-google-plus"></i>
							</a>
                            <span class="comment-cta32"><i class="zmdi zmdi-comment"></i><?php comments_number(); ?></span>
                        </span>
                    </div>
                </div>
				
				
					 <!-- Display comments if there are any -->
					<?php if ( comments_open() || get_comments_number() ) : ?>
						<div class="comments-section">
							<?php
							// Show existing comments
							wp_list_comments();

							// Show the comment form
							
								comment_form( array(
									'title_reply'          => __('Leave a Comment', 'marco'),
									'label_submit'         => __('Submit Comment', 'marco'),
									'comment_notes_after'  => __('If you submit a comment first you must be need login.', 'marco'),
								) );
							?>
						</div>
					<?php endif; ?>

					<?php 
						endwhile;
						endif;
					?>
			
    </div>
</div>
</div>
</div>
</div>
<!-- gallery Area end-->


<?php get_footer(); ?>