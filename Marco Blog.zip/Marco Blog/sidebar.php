
<!-- standard post right-->
<div class="col-lg-4 wow fadeInRight">
  
		<?php if ( is_active_sidebar( 'post-side-bar-5' ) ) : ?>
			<div id="sidebar-widget-area">
				<?php dynamic_sidebar( 'post-side-bar-5' ); ?>
			</div>
		<?php endif; ?>
		
	
		<?php if ( is_active_sidebar( 'post-side-bar-1' ) ) : ?>
			<div id="sidebar-widget-area">
				<?php dynamic_sidebar( 'post-side-bar-1' ); ?>
			</div>
		<?php endif; ?>
		
		<?php if ( is_active_sidebar( 'post-side-bar-2' ) ) : ?>
			<div id="sidebar-widget-area">
				<?php dynamic_sidebar( 'post-side-bar-2' ); ?>
			</div>
		<?php endif; ?>
	
		<?php if ( is_active_sidebar( 'post-side-bar-3' ) ) : ?>
			<div id="sidebar-widget-area">
				<?php dynamic_sidebar( 'post-side-bar-3' ); ?>
			</div>
		<?php endif; ?>
		
		<?php if ( is_active_sidebar( 'post-side-bar-4' ) ) : ?>
			<div id="sidebar-widget-area">
				<?php dynamic_sidebar( 'post-side-bar-4' ); ?>
			</div>
		<?php endif; ?>
</div>