<!DOCTYPE html>
<html lang="zxx">
    
<!-- Mirrored from tf.wpcheatsheet.net/html/marco/post-details.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Mar 2020 20:43:40 GMT -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Post Details</title>
        <!-- === Bootstrap=== -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- === owlcarousel=== -->
        <link rel="stylesheet" href="assets/css/owl.carousel.css">
        <!-- === magnific popup=== -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">
        <!-- === animate css=== -->
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <!-- === matarial icon=== -->
        <link rel="stylesheet" href="assets/css/material-design-iconic-font.min.css">
        <!-- === slicknav === -->
        <link rel="stylesheet" href="assets/css/slicknav.min.css">
        <!-- === owlcarousel=== -->
        <link rel="stylesheet" href="style.css">
        <!-- === responsive css === -->
        <link rel="stylesheet" href="assets/css/responsive.css">
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <!-- Page preloader -->
        <div id="loading">
            <div id="preloader">
                <span></span>
                <span></span>
            </div>
        </div>
        <!-- header Area Start-->
        <div class="header-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-6">
                        <div class="search-bar-left">
                            <span class="search-left"><input type="text" placeholder="Type here..."><i class="zmdi zmdi-search"></i></span>
                        </div>
                    </div>
                    <div class="col-md-6 col-6 text-center">
                        <div class="logo">
                            <a href="index-2.html"><img src="assets/img/logo.png" alt=""></a>
                        </div>
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="header-social-icon">
                            <a href="#"><i class="zmdi zmdi-facebook"></i></a>
                            <a href="#"><i class="zmdi zmdi-twitter"></i></a>
                            <a href="#"><i class="zmdi zmdi-linkedin"></i></a>
                            <a href="#"><i class="zmdi zmdi-instagram"></i></a>
                            <a href="#"><i class="zmdi zmdi-pinterest"></i></a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="responsive_menu"></div>
                        <div class="mainmenu homemenu">
                            <ul>
                                <li><a href="#">Home</a>
                                <ul class="submenu">
                                    <li><a href="index-2.html">Home</a></li>
                                    <li><a href="home-2.html">Home two</a></li>
                                </ul>
                            </li>
                            <li><a href="about.html">About</a></li>
                            <li><a href="travel.html">Travel</a></li>
                            <li><a href="#">Post</a>
                                <ul class="submenu">
                                    <li><a href="standard-post.html">Post</a></li>
                                    <li><a href="post-details.html">Post Details</a></li>
                                </ul>
                            </li>
                            <li><a href="gallery.html">Gallery</a></li>
                            <li><a href="#">Page</a>
                            <ul class="submenu">
                                <li><a href="video-post.html">Video</a></li>
                                <li><a href="faq.html">Faq</a></li>
                                <li><a href="404.html">404</a></li>
                            </ul>
                        </li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Header Area End-->
<!-- gallery Area start-->
<div class="gallery-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title-area text-center">
                    <h3> Post details</h3>
                    <h4><a href="index-2.html">Home / </a><a href="gallery.html"> Post</a></h4>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 wow fadeInLeft">
                <div class="standard-post-left">
                    <div class="standard-single-post">
                        <div class="standard-post-img">
                            <a href="post-details.html"><img src="assets/img/standard-post-img-2.jpg" alt=""></a>
                        </div>
                        <div class="standart-post-text post-details">
                            <h3>Photography</h3>
                            <span class="standard-post-meta"><span class="post-cta11"><i class="zmdi zmdi-account"></i> Chumki Khatun</span> <span class="post-cta22"><i class="zmdi zmdi-alarm"></i> 03 November,2016</span></span>
                            <p>Lorem ipsum dolor sit amet consect etuer adipiscing elit sed diam nonummy nibh euis mod tincidunt ut laoreet
                                minim veniam quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat
                                utate velit esse molestie consequat vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto od
                            nit augue duis dolore te feugait nulla facilisi Nam liber tempor cum soluta nobis eleifend option congue.</p>
                            <p class="content-cta">Lorem ipsum dolor sit amet consectetuer adipiscing elit sed diam nonummy nibh euismod tincidu
                                nt ut laoreet dolore magna aliquam erat volutpat Ut wisi enim ad minim veniam quis nostrud exer
                                facilisis at vero eros et accumsan etiusto odio dignissim qui blandit praesent luptatum zzril delenit
                            augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta assum. </p>
                            
                            Type autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat vel illum dolore eufe
                            ugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzrildelen
                            augue duis dolore te feugait nulla faclisi Nam liber tempor cum soluta nobis eleifend optio ncongue nihil im
                            perdiet doming id quod mazim placerat facer possim assum.
                        </div>
                        <div class="standard-post-social-icon cta">
                            <a href="travel.html" class="details-post-link">Travel</a>
                            <a href="photography.html" class="details-post-link">Photography</a>
                            <a href="lifestyle.html" class="details-post-link">Lifestyle</a>
                            <a href="video.html" class="details-post-link">Video</a>
                            <span class="social-cta-right cta"><span class="share-cta">Share:</span>  <a href="#"><i class="zmdi zmdi-facebook"></i></a><a href="#"><i class="zmdi zmdi-twitter"></i></a><a href="#"><i class="zmdi zmdi-behance"></i></a><a href="#"><i class="zmdi zmdi-instagram"></i></a><a href="#"><i class="zmdi zmdi-google-plus"></i></a>
                        </span>
                    </div>
                </div>
                <div class="travel-content-bottom">
                    <h3>Related Posts</h3>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="content-bottom-img">
                                <a href="#"><img src="assets/img/travel-bottom-img-1.jpg" alt=""></a>
                                <a href="#"><span>To ride your book</span></a>
                                <span class="content-meta">03 Noavember 2016</span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="content-bottom-img">
                                <a href="#"><img src="assets/img/travel-bottom-img-2.jpg" alt=""></a>
                                <a href="#"><span>Your nice photogaphy</span></a>
                                <span class="content-meta">05 November 2016</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="travel-comment cta">
                    <h3>Commaent (3)</h3>
                    <div class="travel-single-comment">
                        <img src="assets/img/comment-img-1.png" alt="">
                        <div class="comment-text">
                            <a href="#"><h4>Jhone doe</h4></a>
                            <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie conse
                            issim qui blandit praesent luptatum .</p>
                            <span>03 November2016 </span>
                            <span class="comment-reply"><a href="#"><i class="zmdi zmdi-mail-reply-all"></i> Reaply</a></span>
                        </div>
                    </div>
                    <div class="travel-single-comment cta">
                        <img src="assets/img/comment-img-2.png" alt="">
                        <div class="comment-text">
                            <a href="#"><h4>Alica doe</h4></a>
                            <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie conse
                            issim qui blandit praesent luptatum .</p>
                            <span>03 November2016 </span>
                            <span class="comment-reply"><a href="#"><i class="zmdi zmdi-mail-reply-all"></i> Reaply</a></span>
                        </div>
                    </div>
                    <div class="travel-single-comment">
                        <img src="assets/img/comment-img-3.png" alt="">
                        <div class="comment-text">
                            <a href="#"><h4>Rubel hosen</h4></a>
                            <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie conse
                            issim qui blandit praesent luptatum .</p>
                            <span>03 November2016 </span>
                            <span class="comment-reply"><a href="#"><i class="zmdi zmdi-mail-reply-all"></i> Reaply</a></span>
                        </div>
                    </div>
                </div>
                <div class="travel-contact">
                    <h3>Leav a Reply</h3>
                    <form action="http://tf.wpcheatsheet.net/html/marco/contact.php">
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" placeholder="Name here">
                            </div>
                            <div class="col-md-6">
                                <input type="text" placeholder="Email here">
                            </div>
                        </div>
                        <textarea placeholder="Post your comment here ..."></textarea>
                        <a href="#" class="post-submit-btn global-hvr">Post comment</a>
                    </form>
                </div>
            </div>
        </div>
        <!-- standard post right-->
        <div class="col-lg-4 wow fadeInRight">
            <div class="standard-post-search">
                <form action="http://tf.wpcheatsheet.net/html/marco/cintact.php">
                    <span><input type="text" placeholder="Search..."><i class="zmdi zmdi-search"></i></span>
                </form>
            </div>
            <div class="home-masonry-right">
                <h3 class="home-masonry-right-title">Categories</h3>
                <ul>
                    <li><a href="#">Fashion <span>30</span></a></li>
                    <li><a href="#">Traavel <span>55</span></a></li>
                    <li><a href="#">Lifestyle <span>66</span></a></li>
                    <li><a href="#">Photography <span>44</span></a></li>
                    <li><a href="#">Other <span>37</span></a></li>
                </ul>
            </div>
            <div class="home-masonry-right cta-2">
                <h3 class="home-masonry-right-title">News letter</h3>
                <p>Enter your email below if you want to
                receive our newsletter</p>
                <form action="http://tf.wpcheatsheet.net/html/marco/contact.php">
                    <input type="text" placeholder="email address">
                    <a class="button-cta" href="#">Subscribe</a>
                </form>
            </div>
            <div class="home-masonry-right cta-3">
                <h3 class="home-masonry-right-title">Recent Post</h3>
                <a href="#" class="home-right-recent-post">
                    <img src="assets/img/home-recent-post-img-1.png" alt="">
                    <div class="home-right-post-text">
                        <h4>Fashion in the Country</h4>
                        <span class="post-date">October 22, 2016</span>
                    </div>
                </a>
                <a href="#" class="home-right-recent-post">
                    <img src="assets/img/home-recent-post-img-2.png" alt="">
                    <div class="home-right-post-text">
                        <h4>Travel in the Country</h4>
                        <span class="post-date">October 23, 2016</span>
                    </div>
                </a>
                <a href="#" class="home-right-recent-post">
                    <img src="assets/img/home-recent-post-img-3.png" alt="">
                    <div class="home-right-post-text">
                        <h4>Click Awsome Photo</h4>
                        <span class="post-date">October 24, 2016</span>
                    </div>
                </a>
                <a href="#" class="home-right-recent-post">
                    <img src="assets/img/home-recent-post-img-4.png" alt="">
                    <div class="home-right-post-text">
                        <h4>The best place</h4>
                        <span class="post-date">October 25, 2016</span>
                    </div>
                </a>
            </div>
            <div class="home-masonry-right cta-4">
                <h3>Tags</h3>
                <a class="home-tag" href="#">Travels</a>
                <a class="home-tag" href="#">Photography</a>
                <a class="home-tag" href="#">Creative</a>
                <a class="home-tag" href="#">News</a>
                <a class="home-tag" href="#">Business</a>
                <a class="home-tag" href="#">Design</a>
                <a class="home-tag" href="#">Experience</a>
                <a class="home-tag" href="#">Adventures</a>
            </div>
            <div class="home-masonry-right cta-5">
                <h3 class="home-masonry-right-title">Instagram</h3>
                <div class="flickr_badge">
                    <script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=6&amp;display=random&amp;size=s&amp;layout=x&amp;source=user&amp;user=34178660@N03"></script>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!-- gallery Area end-->
<!-- home masonry bottom Start-->
<div class="home-masonry-bottom-area wow fadeInUp">
<div class="home-masonry-bottom">
    <div class="home-masonry-bottom-single">
        <a href="assets/img/home-masonry-bottom-img-1-.jpg" class="masonry-light-box"><img src="assets/img/home-masonry-bottom-img-1-.jpg" alt=""></a>
    </div>
    <div class="home-masonry-bottom-single">
        <a href="assets/img/home-masonry-bottom-img-2.jpg" class="masonry-light-box"><img src="assets/img/home-masonry-bottom-img-2.jpg" alt=""></a>
    </div>
    <div class="home-masonry-bottom-single">
        <a href="assets/img/home-masonry-bottom-big-img.jpg" class="masonry-light-box"><img src="assets/img/home-masonry-bottom-big-img.jpg" alt=""></a>
    </div>
    <div class="home-masonry-bottom-single">
        <a href="assets/img/home-masonry-bottom-img-6.jpg" class="masonry-light-box"><img src="assets/img/home-masonry-bottom-img-6.jpg" alt=""></a>
    </div>
    <div class="home-masonry-bottom-single">
        <a href="assets/img/home-masonry-bottom-cta-img.jpg" class="masonry-light-box"><img src="assets/img/home-masonry-bottom-cta-img.jpg" alt=""></a>
    </div>
    <div class="home-masonry-bottom-single">
        <a href="assets/img/home-masonry-bottom-img-7.jpg" class="masonry-light-box"><img src="assets/img/home-masonry-bottom-img-7.jpg" alt=""></a>
    </div>
    <div class="home-masonry-bottom-single">
        <a href="assets/img/home-masonry-bottom-img-8.jpg" class="masonry-light-box"><img src="assets/img/home-masonry-bottom-img-8.jpg" alt=""></a>
    </div>
    <div class="home-masonry-bottom-single">
        <a href="assets/img/home-masonry-bottom-img-4.jpg" class="masonry-light-box"><img src="assets/img/home-masonry-bottom-img-4.jpg" alt=""></a>
    </div>
    <div class="home-masonry-bottom-single">
        <a href="assets/img/home-masonry-bottom-img-10.jpg" class="masonry-light-box"><img src="assets/img/home-masonry-bottom-img-10.jpg" alt=""></a>
    </div>
    <div class="masonry-bottom-overlay">
        <a href="#" class="masonry-bottom-overlay-title">
            <h3>Follow us Instagram</h3>
        </a>
    </div>
</div>
</div>
<!-- home masonry bottom End-->
<!-- home footer menu start-->
<div class="home-footer-area">
<div class="container">
    <div class="row">
        <div class="col-md-3">
            <div class="footer-logo">
                <a href="index-2.html"><img src="assets/img/logo.png" alt=""></a>
            </div>
        </div>
        <div class="col-md-9">
            <div class="mainmenu footer-menu text-right">
                <ul>
                    <li><a href="index-2.html">Home</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="travel.html">Travel</a></li>
                    <li><a href="post-details.html">Post Details</a></li>
                    <li><a href="gallery.html">Gallery</a></li>
                    <li><a href="standard-post.html">Post</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
            </div>
        </div>
    </div>
    <hr>
    <div class="home-footer-social-area">
        <div class="row">
            <div class="col-md-6 col-7">
                <div class="home-footer-social-left">
                    <p>© 2016 - All Rights Reserved</p>
                </div>
            </div>
            <div class="col-md-6 col-5">
                <div class="home-footer-social-right text-right">
                    <a href="#"><i class="zmdi zmdi-facebook"></i></a>
                    <a href="#"><i class="zmdi zmdi-twitter"></i></a>
                    <a href="#"><i class="zmdi zmdi-linkedin"></i></a>
                    <a href="#"><i class="zmdi zmdi-behance"></i></a>
                    <a href="#"><i class="zmdi zmdi-pinterest"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!-- home footer menu End-->
<!-- === Jquery=== -->
<script src="assets/js/jquery-2.1.4.min.js"></script>
<!-- === bootsrap poper js=== -->
<script src="assets/js/popper.min.js"></script>
<!-- === bootsrap=== -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- === owl-carousel=== -->
<script src="assets/js/owl.carousel.min.js"></script>
<!-- === owl-slicknav=== -->
<script src="assets/js/jquery.slicknav.min.js"></script>
<!-- === magnific popup js=== -->
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!-- === isotop js=== -->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!-- === wow js=== -->
<script src="assets/js/wow.min.js"></script>
<!-- === masonry js=== -->
<script src="assets/js/masonary.js"></script>
<!-- === active js=== -->
<script src="assets/js/active.js"></script>
</body>

<!-- Mirrored from tf.wpcheatsheet.net/html/marco/post-details.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Mar 2020 20:43:42 GMT -->
</html>