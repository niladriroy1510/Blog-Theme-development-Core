<?php get_header(); ?>
<!-- gallery Area start-->
<div class="gallery-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title-area text-center">
                   
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 wow fadeInLeft">
                <div class="standard-post-left">
                 
				 <?php if ( have_posts() ) : ?>
				
					<!-- Start of the main loop. -->
						<?php while ( have_posts() ) : the_post();  ?>
				 
				 
				 
				<div class="standard-single-post">
                        <div class="standard-post-img">
							 <a href="<?php the_permalink(); ?>">
							   <?php the_post_thumbnail('full', array('class' => 'img-responsive' )); ?>
							</a>
						</div>
                        <div class="standart-post-text">
                            <h3><?php the_title(); ?></h3>
                            <span class="standard-post-meta"><span class="post-cta11"><i class="zmdi zmdi-account"></i> <?php print get_the_author(); ?></span> <span class="post-cta22"><i class="zmdi zmdi-alarm"></i><?php the_time("g:i A"); ?> - <?php the_time("j F, Y"); ?></span></span>
                            <p><?php the_excerpt(); ?></p>
                        </div>
                        <div class="standard-post-social-icon">
                            <a href="<?php the_permalink(); ?>" class="read-more-btn">Read more</a>
                          
						  <span class="social-cta-right">
						  <span class="share-cta">Share:</span>
						  
							<?php
								// Get the current post URL and title
								$post_url = urlencode(get_permalink());
								$post_title = urlencode(get_the_title());
							?>
							
							<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $post_url; ?>" target="_blank">
								<i class="zmdi zmdi-facebook"></i>
							</a>
							<a href="https://twitter.com/intent/tweet?url=<?php echo $post_url; ?>&text=<?php echo $post_title; ?>" target="_blank">
								<i class="zmdi zmdi-twitter"></i>
							</a>
							
							<a href="https://plus.google.com/share?url=<?php echo $post_url; ?>" target="_blank">
								<i class="zmdi zmdi-google-plus"></i>
							</a>
                            <span class="comment-cta32"><i class="zmdi zmdi-comment"></i><?php comments_number(); ?></span>
                        </span>
                    </div>
                </div>
				
				
			<?php endwhile; ?>
			
					<div class="single-post-pagination">
							<span>
								<?php if (get_previous_post()) : ?>
									<a href="<?php echo get_permalink(get_previous_post()->ID); ?>" class="pagination-cta32">
										<i class="zmdi zmdi-long-arrow-right"></i>
										<?php echo get_previous_post()->post_title; // Optional: Display the previous post title ?>
									</a>
								<?php endif; ?>
								
								<?php if (get_next_post()) : ?>
									<a href="<?php echo get_permalink(get_next_post()->ID); ?>" class="pagination-cta31">
										<i class="zmdi zmdi-long-arrow-left"></i>
										<?php /// echo get_next_post()->post_title; // Optional: Display the next post title ?>
									</a>
								<?php endif; ?>
							</span>
						</div>
						
					<?php else : ?>
					
					<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
					<?php endif; ?>
		
		
    </div>
</div>


<?php get_sidebar(); ?>


</div>
</div>
</div>
<!-- gallery Area end-->


<?php get_footer(); ?>