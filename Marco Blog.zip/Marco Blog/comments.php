<?php
if (post_password_required()) {
    return;
}
?>

<div id="comments" class="comments-area">
    <?php if (have_comments()) : ?>
        <h3 class="comments-title">
            <?php
            printf(
                _nx('One comment', '%1$s comments', get_comments_number(), 'comments title', 'mytheme'),
                number_format_i18n(get_comments_number())
            );
            ?>
        </h3>

        <ul class="comment-list">
            <?php
            wp_list_comments(array(
                'style'      => 'ul',
                'short_ping' => true,
                'avatar_size' => 50,
                'callback'   => 'mytheme_comment_format' // Optional custom format function
            ));
            ?>
        </ul>

        <?php if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
            <nav class="comment-navigation">
                <div class="nav-previous"><?php previous_comments_link(__('&larr; Older Comments', 'mytheme')); ?></div>
                <div class="nav-next"><?php next_comments_link(__('Newer Comments &rarr;', 'mytheme')); ?></div>
            </nav>
        <?php endif; ?>

    <?php else : ?>
        <?php if (!comments_open() && get_comments_number() && post_type_supports(get_post_type(), 'comments')) : ?>
            <p class="no-comments"><?php _e('Comments are closed.', 'mytheme'); ?></p>
        <?php endif; ?>
    <?php endif; ?>

    <!-- Comment Form -->
    <div class="comment-form-area">
        <?php
        comment_form(array(
            'title_reply'          => __('Leave a Comment', 'mytheme'),
            'title_reply_to'       => __('Reply to %s', 'mytheme'),
            'cancel_reply_link'    => __('Cancel Reply', 'mytheme'),
            'label_submit'         => __('Post Comment', 'mytheme'),
            'comment_field'        => '<p><textarea id="comment" name="comment" rows="4" required="required" placeholder="Write your comment here..."></textarea></p>',
            'fields'               => array(
                'author' => '<p><input id="author" name="author" type="text" placeholder="Name" required="required" /></p>',
                'email'  => '<p><input id="email" name="email" type="email" placeholder="Email" required="required" /></p>',
                'url'    => '<p><input id="url" name="url" type="url" placeholder="Website" /></p>',
            )
        ));
        ?>
    </div>
</div>

<?php
/**
 * Custom callback for styling each comment in the comment list.
 */
function mytheme_comment_format($comment, $args, $depth) {
    ?>
    <li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
        <div class="comment-body">
            <div class="comment-author-avatar">
                <?php echo get_avatar($comment, 50); ?>
            </div>
            <div class="comment-content">
                <h5 class="comment-author"><?php comment_author_link(); ?></h5>
                <time class="comment-date"><?php comment_date(); ?> at <?php comment_time(); ?></time>
                <?php if ($comment->comment_approved == '0') : ?>
                    <em class="comment-awaiting-moderation"><?php _e('Your comment is awaiting moderation.', 'mytheme'); ?></em>
                <?php endif; ?>
                <div class="comment-text">
                    <?php comment_text(); ?>
                </div>
                <div class="reply">
                    <?php comment_reply_link(array_merge($args, array(
                        'depth' => $depth,
                        'max_depth' => $args['max_depth']
                    ))); ?>
                </div>
            </div>
        </div>
    </li>
    <?php
}
?>




<style type="text/css">

/* Container for the entire comment section */
	#comments {
		padding: 30px;
		background-color: #f7f9fc;
		border-radius: 8px;
		margin-top: 40px;
		box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
	}

	.comments-title {
		font-size: 2em;
		font-weight: 700;
		color: #333;
		text-align: center;
		margin-bottom: 25px;
		text-transform: uppercase;
		letter-spacing: 1px;
	}

	/* Styling for individual comments */
	.comment-list li {
		display: flex;
		align-items: flex-start;
		padding: 20px;
		border-radius: 8px;
		background-color: #ffffff;
		margin-bottom: 15px;
		box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
		transition: all 0.3s ease;
	}

	.comment-list li:hover {
		transform: translateY(-5px);
	}

	/* Avatar styling */
	.comment-author-avatar img {
		border-radius: 50%;
		width: 60px;
		height: 60px;
		margin-right: 20px;
		box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
	}

	/* Comment content styling */
	.comment-content {
		background-color: #f9fbfd;
		border-radius: 8px;
		padding: 15px;
		flex-grow: 1;
		position: relative;
	}

	.comment-author {
		font-size: 1.2em;
		font-weight: 600;
		color: #007acc;
		margin-bottom: 5px;
	}

	.comment-date {
		font-size: 0.85em;
		color: #888;
		margin-top: 3px;
		font-style: italic;
	}

	.comment-text {
		font-size: 1em;
		line-height: 1.7;
		color: #333;
		margin-top: 10px;
	}

	/* Comment awaiting moderation */
	.comment-awaiting-moderation {
		color: #e67e22;
		font-style: italic;
		background-color: #fff5e6;
		padding: 5px 10px;
		border-radius: 4px;
	}

	/* Reply link styling */
	.reply a {
		font-size: 0.9em;
		color: #007acc;
		font-weight: 600;
		text-decoration: none;
		border: 1px solid #007acc;
		padding: 5px 12px;
		border-radius: 5px;
		transition: all 0.3s ease;
		margin-top: 15px;
		display: inline-block;
	}

	.reply a:hover {
		background-color: #007acc;
		color: #fff;
		border-color: #005fa3;
	}

	/* Comment Form Styles */
	.comment-form-area {
		margin-top: 40px;
		padding: 25px;
		background: #ffffff;
		border-radius: 8px;
		box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
	}

	.comment-form-area h3 {
		font-size: 1.8em;
		font-weight: 700;
		color: #333;
		margin-bottom: 20px;
	}

	.comment-form-area input[type="text"],
	.comment-form-area input[type="email"],
	.comment-form-area input[type="url"],
	.comment-form-area textarea {
		width: 100%;
		padding: 12px;
		font-size: 1em;
		border: 1px solid #ddd;
		border-radius: 6px;
		margin-bottom: 20px;
		background-color: #f7f9fc;
		transition: border 0.3s ease;
	}

	.comment-form-area input[type="text"]:focus,
	.comment-form-area input[type="email"]:focus,
	.comment-form-area input[type="url"]:focus,
	.comment-form-area textarea:focus {
		border-color: #007acc;
		background-color: #ffffff;
		outline: none;
	}

	.comment-form-area textarea {
		height: 120px;
		resize: vertical;
	}

	.comment-form-area input[type="submit"] {
		background: #007acc;
		color: #ffffff;
		padding: 10px 25px;
		border: none;
		border-radius: 6px;
		font-size: 1em;
		cursor: pointer;
		font-weight: 600;
		transition: background 0.3s ease;
	}

	.comment-form-area input[type="submit"]:hover {
		background: #005fa3;
	}

	/* Comment Navigation (Pagination) */
	.comment-navigation {
		display: flex;
		justify-content: space-between;
		margin: 25px 0;
	}

	.comment-navigation .nav-previous,
	.comment-navigation .nav-next {
		font-size: 1em;
		color: #007acc;
		font-weight: 600;
	}

	.comment-navigation a {
		text-decoration: none;
	}

	.comment-navigation a:hover {
		text-decoration: underline;
	}

	/* No comments message */
	.no-comments {
		font-size: 1.3em;
		color: #777;
		text-align: center;
		margin: 40px 0;
		font-style: italic;
	}



</style>