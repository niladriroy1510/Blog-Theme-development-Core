(function ($) {
    "use strict";

    jQuery(document).ready(function ($) {
    
        // -------------------------------------------------------------
        // Welcome slider.
        // -------------------------------------------------------------
        if ($.fn.owlCarousel) {
            $('.welcome-slide').owlCarousel({
                loop: true,
                items: 3,
                autoplay: false,
                nav: true,
                margin: 30,
                navText: ["<i class='zmdi zmdi-long-arrow-left'></i>", "<i class='zmdi zmdi-long-arrow-right'></i>"],
                responsiveClass: true,
                responsive: {
                    0: {
                        items: 1,
                        nav: true
                    },
                    768: {
                        items: 3,
                    },
                    1000: {
                        items: 3
                    }
                }
            });
        }

        // -------------------------------------------------------------
        // masonry active 
        // -------------------------------------------------------------
        if ($.fn.masonry) {
        jQuery('.home-masonry-active, .home-masonry-bottom').masonry({
                // options...
                itemSelector: '.masonry-margin, .home-masonry-bottom-single',
                columnWidth: '.masonry-margin, .home-masonry-bottom-single'
            });
        }
        // -------------------------------------------------------------
        // Magnific popup 
        // -------------------------------------------------------------
        if ($.fn.magnificPopup) {
             jQuery('.masonry-light-box, .blog-popup-cta, .overlay-icon, .video-active').magnificPopup({
                type: 'image',
                mainClass: 'mfp-with-zoom',
                zoom:{
                    enabled:true,
                    duration: 300,
                    easing: 'ease-in-out'
                },
                gallery:{
                    enabled:true
                }
            });
            
            }

        // -------------------------------------------------------------
        // responsive menu start
        // -------------------------------------------------------------
        if ($.fn.slicknav) {
            $('.mainmenu.homemenu ul').slicknav({
                prependTo: ".responsive_menu",
                label: ""
            })
        }
    });

    jQuery(window).load(function () {

        /*====  preloader js Start =====*/
        $('#loading').delay(500).fadeOut('slow',function(){$(this).remove();});
            /*====  animation js Start =====*/
            new WOW().init();
        // -------------------------------------------------------------
        // isotop avtive start
        // -------------------------------------------------------------
        if ($.fn.isotope) {
            jQuery('.gallery-active-item').isotope({
                    itemSelector: '.gallery-single-item',
                    filter: '*'
                });
            jQuery('.gallery-menu li').click(function(){
                var selector = $(this).attr('data-filter');
                jQuery('.gallery-active-item').isotope({
                    filter: selector
                });
            });
            jQuery('.gallery-menu li').on('click', function(){
                $('.gallery-menu li').removeClass('active');
                $(this).addClass('active');
            })
          }
        
        


    });

}(jQuery));